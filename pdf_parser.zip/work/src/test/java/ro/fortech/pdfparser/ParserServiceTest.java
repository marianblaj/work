package ro.fortech.pdfparser;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import ro.fortech.pdfparser.service.ParserPdfService;
import ro.fortech.pdfparser.service.ParserService;

class ParserServiceTest {

    @Test
    void importPdf(String path) throws Exception {
        //new ParserPdfService().importPdf();

        //  new ParserService().importPdf(path);
    }
}