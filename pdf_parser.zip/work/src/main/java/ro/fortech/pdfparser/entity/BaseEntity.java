package ro.fortech.pdfparser.entity;

import javax.persistence.Entity;
import javax.persistence.Id;


public abstract class BaseEntity {


    private long id;


}
